# Felrax Android SDK

Felrax is distributed as a proprietary binary SDK. The source code and generated
API documentation are not included in these placeholder archives.

See `LICENSE` in the sources archive for permitted uses. Project information:
https://github.com/Somepub/felrax
